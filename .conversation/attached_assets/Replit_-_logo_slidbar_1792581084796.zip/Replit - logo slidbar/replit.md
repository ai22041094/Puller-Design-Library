# Puller Design Library

An enterprise catalogue for R&D and Sales teams to search, compare, and manage multi-vendor puller designs.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/puller-library` — React/Vite frontend with dashboard, catalogue, details, vendor/customer directory, and compare routes.
- `artifacts/api-server/src/routes/puller-library.ts` — REST handlers for dashboard summaries and vendor/customer/puller/version operations.
- `lib/api-spec/openapi.yaml` — source of truth for API contracts and generated client hooks.
- `lib/db/src/schema/puller-library.ts` — relational PostgreSQL schema for vendors, customers, pullers, and immutable design versions.
- `artifacts/puller-library/public/seed-images` — workbook-extracted reference images used by the initial seed catalogue.

## Architecture decisions

- React + TypeScript + Vite frontend with the shared Express API service and generated Orval hooks.
- PostgreSQL keeps vendor/customer/puller/version relationships normalized; image paths remain metadata rather than database blobs.
- The first seed set is derived from the supplied YKK ItemMaster and puller reference workbook so the product is usable on first load.
- Design versions are append-only from the UI/API; approved history is not overwritten by later versions.

## Product

- Dashboard metrics and vendor coverage
- Searchable and filterable puller catalogue with visual cards
- Technical puller detail pages with context and documentation links
- Vendor/customer directory with create flows
- Side-by-side design comparison
- Design version history and version creation

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- When API contracts change, run `pnpm --filter @workspace/api-spec run codegen` before using generated hooks or Zod schemas.
- Seed images are served from the frontend artifact's `public/seed-images` directory and referenced by API metadata.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
